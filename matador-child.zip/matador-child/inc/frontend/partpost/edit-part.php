<?php
global $current_user;
wp_get_current_user();
?>
<?php if (is_user_logged_in()): ?>
    <?php if(current_user_can('edit_post', get_the_ID() )): ?>
        <span class="meta-item meta-item-likes small">
        <a class="jrrny-edit-post"
            href="<?= get_permalink(get_the_ID()) ."?action=edit"?>" 
        >
            <span data-toggle="tooltip" data-container="body" data-placement="bottom" title="edit"><i class="fa fa-edit"></i></span>
        </a>
        </span>
    <?php endif; ?>
<?php endif; ?>