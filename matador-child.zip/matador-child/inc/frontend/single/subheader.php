<div id="single-subheader" class="container-fluid">
    <div class="row">
        <div class="col-xs-12 col-sm-6">
            <?php get_template_part("inc/frontend/profile/user-widget");?>            
        </div>
        <div class="col-xs-12 col-sm-6">
            <?php get_template_part("inc/frontend/map/single-map");?>
        </div>
    </div>    
</div>