<?php
get_header();
get_template_part('top');
get_template_part('title-page');
the_post();
?>
<?php
$post_all_images = get_attached_media( "image", get_the_id() );
//$hotelImageId = get_post_meta(get_the_ID(), "_hotel_image_id", true);

$hotelImagesId = [];
for ($i = 1; $i <= 2 ; ++$i){
    $id = get_post_meta(get_the_ID(), '_hotel_image_' . $i . '_id', true);
    if(!empty($id)){
        $hotelImagesId[$i] = $id;
        
    }
}

$post_images = [];
for ($i = 1; $i <= 10 ; ++$i){
    $id = get_post_meta(get_the_ID(), '_p_image_' . $i . '_id', true);
    if(!empty($id)){
        $post_images[$i] = $id;
    }
}
?>

<?php
if($http_hotel_link = get_post_meta(get_the_ID(), "_hotel_link", true)){
    if(empty(parse_url($http_hotel_link)["scheme"])){
        $http_hotel_link = "http://".$http_hotel_link;
    }
}
?>
<div class="container">
    <form id="form-journey" class="form-horizontal" enctype="multipart/formdata" method="post">
        <input type="hidden" name="_token" value="<?php echo $current_user->user_login;?>" />
        <input type="hidden" name="post_id" value="<?=get_the_ID()?>" />
        <?php $thumbId = get_post_thumbnail_id(get_the_id()); ?>
        <input type="hidden" id="jrrny-main-image-id" name="main-image-id" value="<?= $thumbId ?>" data-url="<?= wp_get_attachment_url($thumbId) ?>"/>
        <?php 
        if ($hotelImagesId) :
            foreach ($hotelImagesId as $hotelImageId) :             
                $imageInfo = wp_get_attachment_image_src($hotelImageId, 'thumbnail');
                if (is_array($imageInfo)) :
                    $url = $imageInfo[0];
                ?>
                    <input id="jrrny-himage-<?=$hotelImageId?>" data-url="<?=$url?>" type="hidden" value="<?=$hotelImageId?>" name="imagesh[]">
                <?php endif; 
            endforeach;
            
        endif; 
        
        foreach ($post_images as $imageId) :            
            $imageInfo = wp_get_attachment_image_src($imageId, 'thumbnail');
            if (is_array($imageInfo)) :
                $url = $imageInfo[0];
            ?>
                <input id="jrrny-image-<?=$imageId?>" data-url="<?=$url?>" type="hidden" value="<?=$imageId?>" name="images[]">
            <?php endif; 
        endforeach; ?>
                
        <div class="form-group">
            <div class="col-xs-12 col-sm-6 no-padding">
                <div class="input-group">
                   <?php $place = get_post_meta(get_the_ID(), "_place", true); ?>
                   <span class="input-group-addon"><i class="flaticon flaticon-map-pin-marked"></i></span>
                   <input type="text" name="place" id="place-jrrny" class="form-control" placeholder="Where you went - City & State" value="<?php echo $place; ?>">
               </div>
           </div>
            <div class="col-xs-12 col-sm-6">
                <div class="input-group flaticon-absolute">
                   <?php $activity = get_post_meta(get_the_ID(), "_activity", true); ?>
                   <span class="input-group-addon">FOR <i class="flaticon flaticon-directions-signs-outlines"></i></span>
                   <input type="text" name="activity" id="activity-jrrny" class="form-control" placeholder="What did you do?"  value="<?php echo $activity; ?>">
               </div>
           </div>
        </div>
        <div class="form-group">
            <div class="col-xs-12">
                <label for="dropzone"><i class="flaticon flaticon-photo-camera-outline"></i> Add Images: </label>     
            </div>
            <div class="jrrny-dropzones-container upload-page">
                <div class="col-md-5 sm-upload">
                    <div id="jrrny-himages-dropzone" class="form-group image-upload-dropzone dropzone">
                        <div class="dz-message" data-dz-message>
                            <p><i class="flaticon flaticon-uploading-archive"></i></p>
                            <p>Where did you stay/start?</p>
                            <span class="visible-xs">tap to add up to (2) photos of your jrrny</span>
                            <span class="hidden-xs">drag and drop up to (2) photos or click to browse</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <div id="jrrny-images-dropzone" class="form-group image-upload-dropzone dropzone ">
                        <div class="dz-message" data-dz-message>
                            <p><i class="flaticon flaticon-uploading-archive"></i></p>
                            <p>What did you do?</p>
                            <span class="visible-xs">tap to add up to (12) photos </span>
                            <span class="hidden-xs">drag and drop up to (12) photos or click to browse</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="col-xs-12 col-sm-6 no-padding">
                <div class="input-group">
                   <?php $hotel_name = get_post_meta(get_the_ID(), "_hotel_name", true); ?>
                   <span class="input-group-addon"><i class="flaticon flaticon-house-outline"></i></span>
                   <input type="text" name="hotel-name" id="hotel-name" class="form-control" placeholder="Hotel Name or Starting Point"  value="<?php echo $hotel_name; ?>">
               </div>
           </div>
            <div class="col-xs-12 col-sm-6">
                <div class="input-group">
                   <span class="input-group-addon"><i class="flaticon flaticon-globe-outline"></i></span>
                   <input type="text" name="hotel-link" id="hotel-link" class="form-control" placeholder="Link to where you stayed / started"  value="<?php echo $http_hotel_link; ?>">
               </div>
           </div>
        </div>
        <div class="form-group">
            <div class="col-xs-12">
                <label for="story">
                   <i class="flaticon flaticon-folded-map"></i> What happened on your jrrny? Describe where you ate, where you went, what was fun, and what wasn't!
                </label>                       
                <?php 
                $story = get_the_content();
                $user_id = get_current_user_id();            
                if(is_user_in_role( $user_id, 'blogger') || is_user_in_role( $user_id, 'celebrity') || is_user_in_role( $user_id, 'administrator')){
                    global $wyswig_settings;
                    wp_editor( $story, 'story', $wyswig_settings );
                } else { ?>
                    <textarea id="story" class="form-control" name="story"><?= $story?></textarea>
                <?php } ?>
            </div>
        </div>
        <div class="form-group">
            <div class="col-xs-12">
                <div class="input-group">
                    <?php $insiderTip = get_post_meta(get_the_ID(), "_insider_tip", true); ?>
                   <span class="input-group-addon"><i class="flaticon flaticon-lighting-button"></i></span>
                   <input type="text" name="insider-tip" id="insider-tip" class="form-control" placeholder="Insider tip? - Tell us the secrets only the locals would know" value="<?php echo $insiderTip;?>" />
               </div>
            </div>
        </div>
        <div class="form-group">
            <div class="col-xs-12">
                <button id="journey-data-process" class="btn btn-blue btn-lg">
                    Save
                    <i class="fa processing-icon hide"></i>
                </button>
            </div>
        </div>
    </form>                
</div>