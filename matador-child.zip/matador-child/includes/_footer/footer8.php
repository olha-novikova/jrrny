<div class="span3">
	<?php if (is_active_sidebar("ts-footer-sidebar-1")) dynamic_sidebar("ts-footer-sidebar-1");?>
</div>

<div class="span9">
	<?php if (is_active_sidebar("ts-footer-sidebar-2")) dynamic_sidebar("ts-footer-sidebar-2");?>
</div>