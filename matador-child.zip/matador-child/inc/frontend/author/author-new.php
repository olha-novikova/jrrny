<?php
//global $current_user;
//wp_get_current_user();

if (isset($_GET['author_name'])) {
    $curauth = get_userdatabylogin($author_name);
}
else {
    $curauth = get_userdata(intval($author));
}
$location = get_user_meta($curauth->ID, "_user_location", true);
$likesCount = get_post_meta($curauth->ID, "likes_count");
if (!$location) {
    $location = "";
}
else {
    $location_full = (empty($location["city"]) ? country_full_name($location["country"]) : $location["city"] . ", " . country_full_name($location["country"]) );
}

$home_img = get_option('plc_header_images');
$home_img = explode(',', $home_img);
$headImgId = isset($home_img[0]) ? $home_img[0] : '';

$class = "no-image";
if ($headImgId) {
    $backgroundStyle = 'url(' . $headImgId . ')';
    $class = "image";
}
else {
    $backgroundStyle = '#fff';
}
?>

<div id="main-container-wrap" 
     class="<?php echo esc_attr(ts_main_container_wrap_class('page')) . ' ' . esc_attr($main_container_wrap_class); ?>">    
    <div id="profile-header" class="<?php echo $class; ?> blured" style="background: <?= $backgroundStyle ?>; background-size: cover;">
        <div class="plc-table">
            <div class="plc-table-cell">
                <div class="profile-header-container">
                    <div class="container-fluid">
                        <div id="profile-data-bar" class="row row-eq-height">
                            <div class="col-xs-12 col-sm-4 no-padding-right">
                                <?php if ($curauth->user_url): ?>
                                    <a href="<?php echo $curauth->user_url; ?>">
                                        <?php echo get_avatar($curauth->ID, 256, '', $curauth->user_login); ?>
                                    </a>
                                <?php else: ?>
                                    <?php echo get_avatar($curauth->ID, 256, '', $curauth->user_login); ?>                        
                                <?php endif; ?>
                            </div>
                            <div class="col-xs-12 col-sm-8 no-padding-left">
                                <div id="profile-data-content" class="padding-left-50">
                                    <div class="name">
                                        <?php echo ($curauth->user_firstname && $curauth->user_lastname ? $curauth->user_firstname . " " . $curauth->user_lastname : $curauth->user_login); ?>
                                    </div>
                                    <div class="location">
                                        <?php echo (isset($location_full) ? $location_full : ""); ?> <br />
                                        <?php echo "<a href='{$curauth->user_url}'>{$curauth->user_url}</a>"; ?>
                                    </div>                               
                                    <div class="description">
                                        <?php echo $curauth->description; ?>
                                    </div>
                                    <?php if (is_user_logged_in()) : ?>
                                        <div id="edit-profile_badge">
                                            <?php if (current_user_can('edit_user', $curauth->ID)) : ?>
                                                <a href="" id="jrrny-author-edit-btn" class="btn btn-red" data-toggle="modal" data-target="#jrrny-auhor-edit">edit profile</a>
                                            <?php endif; ?>
                                            <?php if ($current_user->ID != $curauth->ID) : ?>
                                                <a href="" id="jrrny-author-follow-btn" class="btn btn-black-material 
                                                <?= (is_follow($curauth->ID)) ? 'followed' : '' ?>" 
                                                   data-user-id="<?= $curauth->ID ?>">

                                                    <?= (is_follow($curauth->ID)) ? '<i class="fa fa-check"></i>&nbsp;following' : 'follow' ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>        
    </div>
    <div id="profile-stats-bar">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">             
                    <span class="stats jrrnys"><b><?php echo sprintf("%02d", getJrrnysCount($curauth->ID)); ?> </b><small>JRRNYS</small></span>
                    <span class="stats upvoted"><b><?php echo sprintf("%02d", getUpvotesCount($curauth->ID)); ?></b> <small>LIKED</small></span>
                </div>
            </div>
        </div>
    </div>
    <div id="author-tabs">
        <!-- Nav tabs -->
        <div class="tabs">
            <div class="container">
                <ul class="nav nav-tabs nav-justified nav-tab-blue" role="tablist">
                    <li role="presentation">
                        <a href="#liked" aria-controls="liked" role="tab" data-toggle="tab">
                            <i class="fa fa-thumbs-o-up"></i> <span><?php echo (get_current_user_id() == $curauth->ID) ? "i've " : ""; ?>liked</span>
                        </a>
                    </li>
                    <li role="presentation" class="active">
                        <a href="#my_jrrnys" aria-controls="my_jrrnys" role="tab" data-toggle="tab">
                            <i class="fa fa-map-marker"></i> <span><?php echo (get_current_user_id() == $curauth->ID) ? "my " : ""; ?>jrrnys</span>
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#following" aria-controls="following" role="tab" data-toggle="tab">
                            <i class="fa fa-heart"></i> <span>following</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Tab panes -->
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane fade" id="liked">
                <div class="container tab-content">
                    <h2><i class="fa fa-thumbs-o-up"></i> Liked</h2>
                    <div class="posts liked-posts">
                        <?php
                        $likedPostsId = getLikedPostsIds($curauth->ID);
                        if (count($likedPostsId) > 0) {

                            $atts_liked = array(
                                'orderby' => 'post_date',
                                'order' => 'DESC',
                                'posts_per_page' => 10,
                                'post__in' => $likedPostsId,
                                'default_query' => false,
                                'post_type' => array('post', 'sponsored_post', 'featured_destination'),
                                'infinite_scroll' => 'yes_button',
                                'custom_pagination' => true,
                                'post_status' => 'publish',
                            );
                        }
                        else {
                            $atts_liked = array(
                                'post_type' => 'none',
                                'default_query' => false,
                            );
                        }
                        ts_blog_loop('thumbnail', $atts_liked);
                        ?>
                    </div>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane fade in active" id="my_jrrnys">
                <div class="container tab-content">
                    <h2><i class="fa fa-map-marker"></i> Jrrnys</h2>
                    <?php get_template_part('inc/frontend/partauthor/report-part'); ?>
                    <div class="posts personal-posts">
                        <?php
                        $curauth = get_userdata(intval($author));
                        $atts_author = array(
                            'author' => $curauth->ID,
                            'orderby' => 'post_date',
                            'order' => 'DESC',
                            'post_status' => 'publish',
                            'posts_per_page' => 10,
                            'post_type' => array('post', 'sponsored_post', 'featured_destination'),
                            'default_query' => false,
                            'custom_pagination' => true,
                            'infinite_scroll' => 'yes_button'
                        );
                        ts_blog_loop('thumbnail', $atts_author);
                        ?>
                    </div>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane fade" id="following">
                <div class="container tab-content">
                    <h2><i class="fa fa-heart"></i> following</h2>
                    <div class="posts personal-posts">
                        <?php
                        $followUsersIds = getFollowedUsersIds($curauth->ID);
                        foreach ($followUsersIds as $followUserId) :
                            $followUser = get_userdata(intval($followUserId));
                            $firstName = get_user_meta($followUserId, 'first_name', true);
                            $lastName = get_user_meta($followUserId, 'last_name', true);
                            $name = ($firstName && $lastName ? $firstName . '&nbsp;' . $lastName : $followUser->user_nicename);
                            $location = get_user_meta($followUserId, '_user_location', true);
                            $city = (isset($location['city'])) ? $location['city'] : '';
                            $country = (isset($location['country'])) ? $location['country'] : '';
                            $country_full = country_full_name($country);
                            $description = get_user_meta($followUserId, 'description', true);
                            $address = ($city ? $city . ',&nbsp;' . $country_full : $country_full);
                            ?>

                            <div class="row row-eq-height followed-author" id="jrrny-author-<?= $followUserId ?>">
                                <div class="col-sm-3">                            
                                    <a href="<?php echo get_author_posts_url($followUserId); ?>"> 
                                        <?php echo get_avatar($followUserId, 256, '', $followUser->user_login); ?>
                                    </a>                        
                                </div>
                                <div class="col-sm-9">
                                    <h1><?= $name; ?></h1>
                                    <h2><?= $address; ?></h2>
                                    <div class="description"><?= $description ?></div>
                                    <a class="btn button" href="<?= get_author_posts_url($followUserId); ?>">view profile</a>
                                    <a href="#" data-author="<?php echo $followUserId; ?>" data-following="1" class="btn btn-red btn-no-radius meta-item-follow">unfollow</a>
                                </div>
                            </div>

                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 
<?php get_template_part('inc/frontend/profile/edit-form'); ?>