<?php

header('Location: /');