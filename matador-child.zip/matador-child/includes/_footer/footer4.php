<div class="span12">
	<?php if (is_active_sidebar("ts-footer-sidebar-1")) dynamic_sidebar("ts-footer-sidebar-1");?>
</div>