<div id="top-user-<?php echo the_ID(); ?>" class="item">   
    <div><p class="item-title" data-placement="bottom" title="<?php echo the_title(); ?>"><a href="<?php echo esc_url(the_permalink()); ?>"><?php echo the_title(); ?></a></p></div>
</div>