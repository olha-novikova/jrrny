<div class="search-bar-wrapper">
    <h3>Why not plan a trip here today?</h3>
    <p>PROVIDED IN PARTNERSHIP WITH ALLTHEROOMS.COM</p>
    <div class="search-bar-container">
        <div class="alltherooms-logo"></div>
        <iframe id="allTheRoomsWdgt3" src="http://alltherooms.com/widget/searchbar?logo=http%3A%2F%2Falltherooms.com%2Fwidgets%2Fexamples%2Fjohnnyjet.jpg" scrolling="no" frameborder="0" width="100%" height="330px"></iframe>
    </div>
</div>