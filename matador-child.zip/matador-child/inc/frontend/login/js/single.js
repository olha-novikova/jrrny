jQuery(document).ready(function($) {
    $(window).bind("load", function() {
        setTimeout(function(){get_modal('login_form_new_user');},30000);
    });
});