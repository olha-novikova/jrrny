<?php
/*
Template Name: Reset passwod
*/
get_header();
get_template_part('top');
get_template_part('inc/frontend/resetpassword/form-resetpassword');
get_footer();
?>