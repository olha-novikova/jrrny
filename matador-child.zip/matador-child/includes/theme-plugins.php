<?php
/*-----------------------------------------------------------------------------------

- Loads all the .php files found in /includes/plugins/ directory

----------------------------------------------------------------------------------- */
require_once(TS_SERVER_PATH . '/includes/plugins/tgm-plugin-activation/activate-plugins.php');
